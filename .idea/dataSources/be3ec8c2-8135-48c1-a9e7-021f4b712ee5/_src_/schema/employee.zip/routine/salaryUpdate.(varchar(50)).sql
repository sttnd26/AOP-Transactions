CREATE PROCEDURE salaryUpdate(IN dept_name VARCHAR(50))
  begin
update employee_info
set emp_salary = emp_salary + 1000
where emp_dept = dept_name;
end;
