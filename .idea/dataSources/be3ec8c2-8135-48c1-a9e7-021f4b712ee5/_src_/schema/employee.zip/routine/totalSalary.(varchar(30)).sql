CREATE FUNCTION totalSalary(dept_name VARCHAR(30))
  RETURNS INT
  begin
declare total int ;
select sum(salary) into total from employee_info
where emp_dept = dept_name;
return total;
end;
