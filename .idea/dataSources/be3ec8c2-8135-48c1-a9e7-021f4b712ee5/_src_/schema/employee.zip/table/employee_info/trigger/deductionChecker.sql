CREATE TRIGGER deductionChecker
AFTER UPDATE ON employee_info
FOR EACH ROW
  begin
if old.emp_salary>new.emp_salary then
insert into recordtable
set emp_name = old.emp_name ,
updated_by = 'admin',
changed_salary = new.emp_salary,
updatinon_date = now();
end if ;
end;
